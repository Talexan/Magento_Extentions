<?php 
namespace NP\NowPayments\Api;
 
 
interface IpnManagementInterface {


	/**
	 * @param string $param
	 * @return string
	 */
	
	public function getPost($param = null);
}
